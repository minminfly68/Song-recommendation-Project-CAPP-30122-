CAPP 30122: Regular expression Lab

README.txt: this file

Text files:
  test0.txt

  Chicago.txt: (old) Wikipedia entry for Chicago

  Errors.txt: Shakespeare's Comedy of Errors from Project Gutenberg
  Macbeth.txt: Shakespeare's Macbeth from Project Gutenberg
  RJ.txt: Shakespeare's Romeo and Juiet from Project Gutenberg

  chant.txt: nerdy chant

  emails.txt: file with email addresses

Some Python files:
  geometry.py: distribution from CS121 lab 3.
  list_exercises.py
  play.py
  plot_lab.py

