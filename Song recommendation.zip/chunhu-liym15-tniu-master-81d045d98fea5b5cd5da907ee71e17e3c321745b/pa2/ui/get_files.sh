#!/bin/sh

echo "Getting PA2 files..."

wget -nv -O pa2-files.tgz https://www.classes.cs.uchicago.edu/archive/2020/winter/30122-1/pa2-files.tgz
tar xvzf pa2-files.tgz
