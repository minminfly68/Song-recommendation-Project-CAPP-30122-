echo "Getting PA4 files..."

wget -nv -O pa4-files.tgz https://www.classes.cs.uchicago.edu/archive/2020/winter/30122-1/pa4-files.tgz
tar xvzf pa4-files.tgz
