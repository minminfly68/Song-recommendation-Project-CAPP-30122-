# CAPP30122 W'20: Building decision trees assignment

ex.csv           -- Example from chapter on Classification and
    Decision Trees from Introduction to Data Mining by Tan, Steinbach, and Kumar
   (http://www-users.cs.umn.edu/~kumar/dmbook/ch4.pdf.)

pima-indians-diabetes.csv -- This data set contains anonymized
  information on women from the `Pima Indian Tribe.
  See http://archive.ics.uci.edu/ml/datasets/Pima+Indians+Diabetes
  for more information

README.txt                -- this file
