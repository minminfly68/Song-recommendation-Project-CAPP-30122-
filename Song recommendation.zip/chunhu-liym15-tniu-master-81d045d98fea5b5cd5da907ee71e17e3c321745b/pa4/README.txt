# Building decision trees

transform.py     -- skeleton code for Task 1
decision_tree.py -- skeleton code for Task 2

test_transform.py -- test code for Task 1
test_decision_tree.py -- test code for Task 2

data             -- sample data

README.txt       -- this file
