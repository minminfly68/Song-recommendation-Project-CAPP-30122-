CAPP 30122: "The Markovian Candidate": Speaker Attribution Using Markov Models

hash_table.py: you will modify this file to implement a hash table
markov.py: you will modify this file to implement a Markov model and to perform
           speaker attribution


speeches: contains sample text to use for testing
