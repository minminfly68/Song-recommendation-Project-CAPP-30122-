echo "Getting PA3 files..."

wget -nv -O pa3-files.tgz https://www.classes.cs.uchicago.edu/archive/2020/winter/30122-1/pa3-files.tgz
tar xvzf pa3-files.tgz
